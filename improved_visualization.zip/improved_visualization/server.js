const express = require('express');
const app = express();
const path = require('path');
const mysql = require('mysql')
const PORT = process.env.PORT || 3000;

app.use(express.static(path.join(__dirname, 'public')));

const pool = mysql.createPool({
    connectionLimit:10,
    host: 'localhost',
    user:"root",
    password:"",
    database: "pos_db"
})

app.get('/api/pos-utilization', (req, res)=>{
    try{
        pool.getConnection((err, connection)=>{
            if(err){
                console.error('Error getting mysql connection!', err);
                res.status(500).json({error : 'Internal Server Error'})
                return;
            }

            const query =``
        })
    }catch(error){
        console.error("Error:", error);
        res.status(500).json({error: "Internal Server Error"});
    }
})

app.listen(PORT, ()=>{
    console.log(`This server is running on port ${PORT} `)
})