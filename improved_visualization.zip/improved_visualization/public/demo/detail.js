    // Define the toggleDropdown function globally
    var dropdownMenu = document.getElementById("dropdownmenu");
    let clickCount = 0;

    function toggleDropdown() {
        clickCount ++;
        if(clickCount % 2 === 1){
            dropdownMenu.style.display = "block";
        }else{
            dropdownMenu.style.display = "none";
        }
    }
document.addEventListener("DOMContentLoaded", (event) => {

    var isClickInside = dropdownMenu.contains(event.target);
    var isDropdownButton  = event.target.id === "downbtn"
    if(!isClickInside && !isDropdownButton){
        dropdownMenu.style.display = "none";
        console.log('functionality checked')
        clickCount = 0;
    }

    // Function for filtering terminals
    function filterTerminalFunction() {
        var input, filter, table, tr, td, i, txtValue;
        input = document.getElementById("filterInput");
        filter = input.value.toUpperCase();
        table = document.getElementById('example');
        tr = table.getElementsByTagName('tr');
        for (i = 0; i < tr.length; i++) {
            td = tr[i].getElementsByTagName("td")[0];
            if (td) {
                txtValue = td.textContent || td.innerText;
                if (txtValue.toUpperCase().indexOf(filter) > -1) {
                    tr[i].style.display = "";
                } else {
                    tr[i].style.display = 'none';
                }
            }
        }
    }

    // Event listener for the filter input
    var filterInput = document.getElementById('filterInput');
    if (filterInput) {
        filterInput.addEventListener("keyup", filterTerminalFunction);
    }

    // Function to close dropdown when clicking outside
    function closeDropdown(event) {
        var dropdownMenu = document.getElementById('dropdownmenu');
        var downBtn = document.querySelector('.downbtn');
        if (!event.target.matches('.downbtn') && !dropdownMenu.contains(event.target)) {
            dropdownMenu.classList.remove('show');
        }
    }

    // Event listener to close dropdown
    window.addEventListener('click', closeDropdown);
});
