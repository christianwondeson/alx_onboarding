
    // Define the toggleDropdown function globally
    var dropdownMenu = document.getElementById("dropdownmenu");
    let clickCount = 0;

    function toggleDropdown() {
        clickCount ++;
        if(clickCount % 2 === 1){
            dropdownMenu.style.display = "block";
        }else{
            dropdownMenu.style.display = "none";
        }
    }
document.addEventListener("DOMContentLoaded", (event) => {
    var isClickInside = dropdownMenu.contains(event.target);
    var isDropdownButton  = event.target.id === "downbtn"
    if(!isClickInside && !isDropdownButton){
        dropdownMenu.style.display = "none";
        clickCount = 0;
    }

    // Function for filtering terminals
    function filterTerminalFunction() {
        var input, filter, table, tr, td, i, txtValue;
        input = document.getElementById("filterInput");
        filter = input.value.toUpperCase();
        table = document.getElementById('example');
        tr = table.getElementsByTagName('tr');
        for (i = 0; i < tr.length; i++) {
            td = tr[i].getElementsByTagName("td")[0];
            if (td) {
                txtValue = td.textContent || td.innerText;
                if (txtValue.toUpperCase().indexOf(filter) > -1) {
                    tr[i].style.display = "";
                } else {
                    tr[i].style.display = 'none';
                }
            }
        }
    }

    // Event listener for the filter input
    var filterInput = document.getElementById('filterInput');
    if (filterInput) {
        filterInput.addEventListener("keyup", filterTerminalFunction);
    }

    // Function to close dropdown when clicking outside
    function closeDropdown(event) {
        var dropdownMenu = document.getElementById('dropdownmenu');
        var downBtn = document.querySelector('.downbtn');
        if (!event.target.matches('.downbtn') && !dropdownMenu.contains(event.target)) {
            dropdownMenu.classList.remove('show');
        }
    }

    // Event listener to close dropdown
    window.addEventListener('click', closeDropdown);

    var printBtn = document.getElementById('print')
    if(printBtn){
        printBtn.addEventListener('click', ()=>{
            window.print()
        })
    }
    function exportHTML() {
        // Get the HTML content to export
        var htmlContent = document.documentElement.outerHTML;
    
        // Modify the HTML content to include embedded CSS styles
        var modifiedHTML = `
            <style>
                /* CSS styles here */
                body {
                    font-family: Arial, sans-serif;
                    color: #333;
                    background-color: #f9f9f9;
                    padding: 20px;
                }
                /* Add more styles as needed */
            </style>
            ${htmlContent}
        `;
    
        // Create a Blob containing the modified HTML content
        var blob = new Blob([modifiedHTML], { type: 'text/html' });
    
        // Create a temporary anchor element
        var a = document.createElement('a');
        a.download = 'exported_page.html';
        a.href = URL.createObjectURL(blob);
    
        // Trigger a click event on the anchor element to start the download
        a.click();
    
        // Release the object URL
        URL.revokeObjectURL(a.href);
    }
    

    
    var exportBtn = document.getElementById('export')
    if(exportBtn){
        document.addEventListener('click', ()=>{
            exportHTML();
            console.log("export button was clicked")
        })
    }
});
