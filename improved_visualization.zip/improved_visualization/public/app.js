const data = {
    labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
    datasets: [{
        label: 'Pos Utilization',
        data: [65, 29, 65, 81, 56, 55, 40],
        fill: {
            target: 'origin', // Fill from origin to the data point
            above: 'rgba(220, 237, 200, 0.61)', // Color for above the line
          },
        borderColor: 'rgb(0, 128, 0)', // Green color
        backgroundColor:'rgba(220, 237, 200, 0.61)',
        borderWidth: 2,
        tension: 0.1
    },
    {
        label: 'Total Txn Per Day',
        data: [40, 55, 56, 41, 80, 59, 65],
        fill: {
            target: 'origin', // Fill from origin to the data point
            above: 'rgba(179, 229, 252, 0.61)', // Color for above the line
          },
        borderColor: '#0a5b76', // Black color
        backgroundColor:'rgba(179, 229, 252, 0.61)',
        borderWidth: 2,
        tension: 0.1
    }]
};

const config = {
    type: 'line',
    data: data,
    options: {
        responsive: true,
        plugins: {
            legend: {
                position: 'top',
            },
            title: {
                display: true,
                text: 'Pos Utilization'
            },
            tooltip: {
                callbacks: {
                    label: function (context) {
                        var label = context.dataset.label || '';
                        if (label) {
                            label += ': ';
                        }
                        if (context.parsed.y !== null) {
                            label += context.parsed.y + '%';
                        }
                        return label;
                    }
                }
            },
            annotation: {
                annotations: [{
                    type: 'line',
                    mode: 'vertical',
                    scaleID: 'x-axis-0',
                    value: new Date().getTime(),
                    borderColor: 'rgb(255, 99, 132)',
                    borderWidth: 2,
                    label: {
                        enabled: true,
                        content: 'Deployment Date'
                    }
                }]
            }
        }
    },
};



// Create chart
const ctx = document.getElementById('myChartCanvas').getContext('2d');
const myChart = new Chart(ctx, config);

const date = new Date();
const options = { year: 'numeric', month: 'long', day: 'numeric' };

function myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
  }
  
  function filterFunction() {
    const input = document.getElementById("myInput");
    const filter = input.value.toUpperCase();
    const div = document.getElementById("myDropdown");
    const a = div.getElementsByTagName("a");
    for (let i = 0; i < a.length; i++) {
      txtValue = a[i].textContent || a[i].innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        a[i].style.display = "";
      } else {
        a[i].style.display = "none";
      }
    }
  }

  function filterGraph(days) {
    const newData = {
        labels: data.labels.slice(-days),
        datasets: data.datasets.map(dataset => ({
            ...dataset,
            data: dataset.data.slice(-days)
        }))
    };
    myChart.data = newData;
    myChart.update();
}




function filterTerminalFunction() {
    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById("myInput");
    filter = input.value.toUpperCase();
    table = document.getElementById('example');
    tr = table.getElementsByTagName('tr');
    for (i = 0; i < tr.length; i++) {
        td = tr[i].getElementsByTagName("td")[0]; // Get the first cell in each row
        if (td) {
            txtValue = td.textContent || td.innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = "";
            } else {
                tr[i].style.display = "none";
            }
        }
    }
}
// page redirect

var rows = document.querySelectorAll('#table-body tr')

rows.forEach((row)=>{
    row.addEventListener('click', ()=>{
        console.log("this tr is clicked")
        var terminalName = row.querySelector('td:first-child').innerText;
        window.location.href = "./demo/page.html?terminal=" + encodeURIComponent(terminalName);
    })
})
